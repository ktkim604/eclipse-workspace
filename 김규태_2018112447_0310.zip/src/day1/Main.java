package day1;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		
		int a;
		int b;
		int c;
		
		a = sc.nextInt();
		b = sc.nextInt();
		c = sc.nextInt();
		
		System.out.print(c);
		System.out.print(' ');
		System.out.print(b);
		System.out.print(' ');
		System.out.print(a);
		
	}

}
