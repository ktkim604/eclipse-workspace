package hash;

public class Entry {

	 private int value;



	 public void setValue(int val)

	 {

	     value = val;

	 }



	 public int getValue()

	 {

	     return value;

	 }

	}
